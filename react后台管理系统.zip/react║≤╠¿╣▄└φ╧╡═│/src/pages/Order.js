import React, { Component } from 'react';
import {Input,message, Card ,Button,Radio, Table, Divider, Tag ,Modal} from 'antd'; 

const { Search } = Input;
export default class Order extends Component{
    constructor(){
        super()
        this.state={
          datakb:[],
          columns : [
            {
              title: '订单号',
              dataIndex: 'orderhao',
              key: 'orderhao',
            },
            {
              title: '收件人',
              dataIndex: 'sjr',
              key: 'sjr',
            },
            {
              title: '订单状态',
              dataIndex: 'ztai',
              key: 'ztai',
            },
            {
              title: '订单总价',
              key: 'jiege',
              dataIndex: 'jiege',
            }, {
              title: '创建时间',
              dataIndex: 'time',
              key: 'time',
            render:text=><span>{this.timestampToTime(text)}</span>
            },
            {
              title: '操作',
              key: 'action',
              render: (text, record) => (
                <span>
                      <Button type="link">查看详情</Button>
                </span>
              ),
            },
          ],
          data :[
            {
              key: '1',
              orderhao: '1582214047642',
              sjr: '张三',
              ztai: '未支付',
              jiege: '300￥',
              time:1582214047642
            },
            {
              key: '2',
              orderhao: '1582314047642',
              sjr: '李四',
              ztai: '已支付',              
              jiege: '2300￥',
              time:1582314047642
            },
            {
              key: '3',
              orderhao: '1582214047643',
              sjr: '王五',
              ztai: '未支付',
              jiege: '270￥',
              time:1582214047642
            },
            {
              key: '4',
              orderhao: '1582314047644',
              sjr: '范海辛',
              ztai: '已支付',              
              jiege: '18300￥',
              time:1582314047642
            }
          ],
        }
    }
    //初始化拷贝表单数据
    componentDidMount(){
      this.setState({
        datakb:this.state.data
      })
    }
    //转化时间格式
    timestampToTime(timestamp) {
      let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
      let Y = date.getFullYear() + '-';
      let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
      let D = date.getDate() + ' ';
      let h = date.getHours() + ':';
      let m = date.getMinutes() + ':';
      let s = date.getSeconds();
      let w = '上午';
      if(date.getHours()>=12){
          w='下午'
      }else{
          w='上午'
      }
      
      return Y+M+D+w+h+m+s;
    }
    //提示框
    success = () => {
      message.success('搜索成功');
    };
    success1 = () => {
      message.error('没有此订单');
    };
    //搜索
    Searchs(value){
      var arr=[],arrl=[],arrs=[]
      arr=this.state.datakb.filter((item)=>{
        if(item.orderhao==value){
          return item
        }else{
          return
        }
      })
      arrl=this.state.datakb.filter((item)=>{
        if(item.sjr==value){
          return item
        }else{
          return
        }
      })
      if(arr.length>0){
        arrs=arr
        this.setState({
          data:arrs
        })
        {this.success()}
      }else if(arrl.length>0){
        arrs=arrl
        this.setState({
          data:arrs
        })
        {this.success()}
      }else{
        {this.success1()}
      }
      
    }
    render(){
      const { visible, confirmLoading, ModalText } = this.state;
        return(
            <div style={{ background: '#ECECEC' }}>
            <Card title="订单管理" bordered={false} style={{ width: '100%' }} 
            extra={<Search
              placeholder="请输入订单号或者收件人"
              enterButton="搜索"
              size="large"
              onSearch={value => {this.Searchs(value)}}
            />}
            >
            
              <Table  bordered={true}  columns={this.state.columns} dataSource={this.state.data} />
              <div>
                
              </div>
            </Card>
          </div>
        )
    }
}