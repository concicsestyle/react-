import React, { Component } from 'react';
import {BrowserRouter as Router,Switch,Route,NavLink,Redirect} from "react-router-dom";
import './Dashbord.css'
import Charts from './Charts'
import User from './User'
import Goods from './Goods'
import Store from './Store'
import Order from './Order'
import Errors from './Errors'
import Part from './Part'


import { Layout } from 'antd';

import {getLogin} from '../api/common'
import { Menu, Icon ,Divider,Avatar,Input} from 'antd';

const { Search } = Input;
const { SubMenu } = Menu;
const { Header, Footer, Sider, Content } = Layout;



  
export default class Dashbord extends Component{
    constructor(){
        super()
    }
    handleClick = e => {
        if(e.key=='2'){
          this.props.history.push("/index/goods")
        }else if(e.key=='3'){
          this.props.history.push("/index/store")
        }else if(e.key=='4'){
          this.props.history.push("/index/user")
        }else if(e.key=='5'){
          this.props.history.push("/index/order")
        }else if(e.key=='6'){
          this.props.history.push("/index/part")
        }
      };
    render(){
        return(

            <React.Fragment>
            <Layout className='doxds'>
              <Sider className="siders"
              width="250">
                  <div className="ioce">后台管理系统</div>
                  
                  <Menu
                  
                theme='dark'
                onClick={this.handleClick}
                style={{ width: 250}}
                defaultSelectedKeys={['1']}
                
                mode="inline"
            >
          <Menu.Item key="1" style={{ height: 50}}><NavLink to="/index/charts">首页</NavLink></Menu.Item>
          <SubMenu
          key="sub1"
          title={
            <span>
              <Icon type="shop" />
              <span>商品</span>
            </span>
          }
         
        >
          <Menu.Item key="2"  style={{ height: 50}}><Icon type="account-book" />商品管理</Menu.Item>
          <Menu.Item key="3"  style={{ height: 50}}><Icon type="calendar"></Icon>分类管理</Menu.Item>
          </SubMenu>
          <SubMenu
          key="sub3"
          title={
            <span>
              <Icon type="user" />
              <span>用户</span>
            </span>
          }
        >
          <Menu.Item key="4" style={{ height: 50}}><Icon type="user-add" />用户管理</Menu.Item>
          <Menu.Item key="6" style={{ height: 50}}><Icon type="user-add" />角色管理</Menu.Item>
          </SubMenu>
          <SubMenu
          key="sub4"
          title={
              
            <span >
              <span>订单</span>
            </span>
          }
        >
          <Menu.Item key="5" style={{ height: 50}}><Icon type="pay-circle" />订单管理</Menu.Item>
          </SubMenu>
      </Menu>



                </Sider>
              <Layout>
                <Header className="headders">
                  <Search
                    placeholder="search..."
                    onSearch={value => console.log(value)}
                   style={{width:200}}
                  />
                  <div>
                    <Avatar size="large" style={{ backgroundColor: '#c2c5ca' }} icon="user" />
                    <span className='usernames'>admin</span>
                  </div>
                </Header>
                <div className="navbut"></div>
                <Content className="container">
                    <Switch>{/* 默认匹配一个 */}

                        <Route path="/index/charts" component={Charts}></Route>
                        <Route path="/index/user" component={User}></Route>
                        <Route path="/index/goods" component={Goods}></Route>
                        <Route path="/index/store" component={Store}></Route>
                        <Route path="/index/order" component={Order}></Route>
                        <Route path="/index/part" component={Part}></Route>
                        <Redirect from="/index" to="/index/charts"></Redirect>{/* 重定向,404的是路由到哪里 */}
                    </Switch>{/* 默认匹配一个 */}

                </Content>
                <Footer className="footer">Created By Xue At 2020.02</Footer>
              </Layout>
            </Layout>
          </React.Fragment>

           
        )
    }
}