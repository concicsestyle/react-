import React, { Component } from 'react';
import { Card ,message,Button,Radio,Select, Table, Divider,Pagination, Tag ,Modal,Form, Input,Icon} from 'antd';
import './Goods.css'

const { Option } = Select;

class Goods extends Component{
    constructor(){
        super()
        this.state={
          keys:0,
          type:'add',
          columns : [
            {
              title: '名称',
              dataIndex: 'name',
              key: 'name',
            },
            {
              title: '价格',
              dataIndex: 'jage',
              key: 'jage',
            },
            {
              title: '商品描述',
              dataIndex: 'time',
              key: 'time',
            },
            {
              title: '商品状态',
              key: 'ztai',
              dataIndex: 'ztai',
              render: (text, record) => (
                <span>
                      <Button onClick={()=>{this.ztais(record,record.ztai)}}>{record.ztai=='1'?'下架':'上架'}</Button>
                      <Button type="link">{record.ztai=='1'?'销售中':'未销售'}</Button>
                </span>
              ),
            },
            {
              title: '操作',
              key: 'action',
              render: (text, record) => (
                <span>
                  <Button onClick={()=>{this.showModal('xiu',record)}}>修改</Button>
                  <Divider type="vertical" />
                  <Button onClick={()=>{this.deletes(record.key)}}>删除</Button>
                </span>
              ),
            },
          ],
          data :[
            {
              key: '1',
              name: 'John Brown',
              jage: '32￥',
              time: 'New York No. 1 Lake Park',
              ztai:'0'
            },
            {
              key: '2',
              name: 'Jim Green',
              jage: '42￥',
              time: 'London No. 1 Lake Park',
              ztai:'1'
            },
            {
              key: '3',
              name: 'Joe Black',
              jage: '52￥',
              time: 'Sidney No. 1 Lake Park',
              ztai:'0'
            },
            {
              key: '4',
              name: 'John Brown',
              jage: '32￥',
              time: 'New York No. 1 Lake Park',
              ztai:'1'
            },
            {
              key: '5',
              name: 'Jim Green',
              jage: '42￥',
              time: 'London No. 1 Lake Park',
              ztai:'0'
            },
            {
              key: '6',
              name: 'Joe Black',
              jage: '52￥',
              time: 'Sidney No. 1 Lake Park',
              ztai:'1'
            },
          ],
          
            ModalText: 'Content of the modal',
            visible: false,
            confirmLoading: false,
            total:10,
        }
    }
    //提示框
    success1 = () => {
      message.success('修改成功');
    };
    success2 = () => {
      message.success('添加成功');
    };
    success3 = () => {
      message.success('删除成功');
    };
    handleSubmit (type,e){
      e.preventDefault();
      this.props.form.validateFields((err, values) => {
        if (!err) {
          if(type=='add'){
            var key=new Date()-1
            var val=values
            val.jage=val.jage+'￥'
            val.key=key
            var list=this.state.data
            list.push(values)
          this.setState({
            data:list,
            total:list.length
          })
          this.setState({})
          {this.success2()}
          }else{
            this.setState({
              type:'add'
            })
            var obj=values
            obj.key=this.state.keys
            obj.jage=obj.jage+'￥'
          var list=this.state.data.map((item)=>{
            if(item.key==this.state.keys){
              item=obj
            }
            return item
           })
          this.setState({
            data:list
          })
          {this.success1()}
          }

          this.handleOk()
          this.props.form.setFields({"name":""})
          this.props.form.setFields({"jage":""})
          this.props.form.setFields({"time":""})
          this.props.form.setFields({"ztai":""})

        }
      });
    };
  

    
    showModal(type,val) {
      if(type=='xiu'){
        this.setState({
          keys:val.key,
          type:'xiu'
        })
        this.props.form.setFieldsValue({"name":val.name})
        this.props.form.setFieldsValue({"jage":val.jage.split('￥')[0]})
        this.props.form.setFieldsValue({"time":val.time})
        this.props.form.setFieldsValue({"ztai":val.ztai})
      }
      this.setState({
        visible: true,
      });
      
    };
    handleOk = () => {
      
        this.setState({
          visible: false,
          confirmLoading: false,
        });
    };
    handleCancel = () => {
      this.props.form.setFields({"name":""})
          this.props.form.setFields({"jage":""})
          this.props.form.setFields({"time":""})
          this.props.form.setFields({"ztai":""})
      this.setState({
        visible: false,
      });
      
    };
    //初始化页数
    componentDidMount(){
      this.setState({
        total:this.state.data.length
      })
    }
    deletes(id){
      var list=this.state.data.filter((item)=>{
          return item.key!=id
      })
      this.setState({
        data:list,
        total:list.length
      })
      this.setState({})
      {this.success3()}
    }
    ztais(datas,ztai){
      var i
      if(ztai=='1'){
        i=0
      }else{
        i=1
      }
      var obj=datas
      obj.ztai=i
      var arr=this.state.data.map((item)=>{
        if(item.key==obj.key){
          item=obj
        }
        return item
      })
      this.setState({
        data:arr,
      })

    }


    render(){
      const { getFieldDecorator } = this.props.form;
      const { visible, confirmLoading, ModalText,type } = this.state;
        return(
            <div style={{ background: '#ECECEC' }}>
            <Card title="商品管理" bordered={false} style={{ width: '100%' }} extra={<Button onClick={()=>{this.showModal()}} type="primary" icon="plus">添加商品 </Button>} >
              <Table
                  bordered={true}  columns={this.state.columns} dataSource={this.state.data}
                  pagination={{
                    pageSize: 5,
                    total:this.state.total,}}
               />
              <div>
                <Modal
                  title="添加商品"
                  visible={visible}
                  onOk={(event)=>{this.handleSubmit(type,event)}}
                  okText={'确认'}
                  cancelText={'取消'}
                  confirmLoading={confirmLoading}
                  onCancel={this.handleCancel}
                >
                  
                <Form onSubmit={this.handleSubmit}  className="login-form">
                  <Form.Item label="名称">
                    {getFieldDecorator('name', {
                      rules: [
                        {
                          required: true,
                          message: '商品名称不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  
                  <Form.Item label="价格">
                    {getFieldDecorator('jage', {
                      rules: [
                        {
                          required: true,
                          message: '商品价格不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  <Form.Item label="描述">
                    {getFieldDecorator('time', {
                      rules: [
                        {
                          required: true,
                          message: '商品描述不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  <Form.Item label="状态">
                    {getFieldDecorator('ztai', {
                      rules: [
                        {
                          required: true,
                          message: '请选择商品状态!',
                        },
                      ],
                    })
                  (<Select
                  style={{width : 180}}
                    placeholder="商品是否上架"   
                    onChange={this.handleSelectChange}
                  >
                    <Option value="1">上架</Option>
                    <Option value="0">下架</Option>
                  </Select>)}
                  </Form.Item>
                </Form>
                </Modal>
              </div>
            </Card>
          </div>
        )
    }
}
 
export default  Form.create()(Goods);