import React, { Component } from 'react';

export default class Errors extends Component{
    constructor(){
        super()
    }
    render(){
        return(
            <div className="">
                我是404页面
            </div>
        )
    }
}