import React, { Component } from 'react';
import { Card ,message,Button,Radio,Select, Table, Divider,Pagination, Tag ,Modal,Form, Input,Icon} from 'antd';
import './Store.css'

class Store extends Component{
    constructor(){
        super()
        this.state={
          type:'add',
            columns : [
              {
                title: '名称',
                dataIndex: 'name',
                key: 'name',
                className:'ww',
                render: text => <a>{text}</a>,
              },
              {
                title: '操作',
                key: 'action',
                render: (text, record) => (
                  <span>
                  <Button onClick={()=>{this.showModal('xiu',record)}}>修改</Button>
                  <Divider type="vertical" />
                  <Button onClick={()=>{this.deletes(record.key)}}>删除</Button>
                </span>
                ),
              },
            ],
            data :[
              {
                key: '1',
                name: 'John Brown',
                jage: '32￥',
                time: 'New York No. 1 Lake Park',
                tags: ['nice', 'developer'],
              },
              {
                key: '2',
                name: 'Jim Green',
                jage: '42￥',
                time: 'London No. 1 Lake Park',
                tags: ['loser'],
              },
              {
                key: '3',
                name: 'Joe Black',
                jage: '52￥',
                time: 'Sidney No. 1 Lake Park',
                tags: ['cool', 'teacher'],
              },
              {
                key: '4',
                name: 'John Brown',
                jage: '32￥',
                time: 'New York No. 1 Lake Park',
                tags: ['nice', 'developer'],
              },
              {
                key: '5',
                name: 'Jim Green',
                jage: '42￥',
                time: 'London No. 1 Lake Park',
                tags: ['loser'],
              },
              {
                key: '6',
                name: 'Joe Black',
                jage: '52￥',
                time: 'Sidney No. 1 Lake Park',
                tags: ['cool', 'teacher'],
              },
            ],
            
              ModalText: 'Content of the modal',
              visible: false,
              confirmLoading: false,
               total:10,
          }
      }
       //提示框
    success1 = () => {
      message.success('修改成功');
    };
    
    success2 = () => {
      message.success('添加成功');
    };
    success3 = () => {
      message.success('删除成功');
    };
    handleSubmit (type,e){
      e.preventDefault();
      this.props.form.validateFields((err, values) => {
        if (!err) {
          if(type=='add'){
            var key=new Date()-1
            var val=values
            val.jage=val.jage+'￥'
            val.key=key
            var list=this.state.data
            list.push(values)
          this.setState({
            data:list,
            total:list.length
          })
          this.setState({})
          {this.success2()}
          }else{
            this.setState({
              type:'add'
            })
            var obj=values
            obj.key=this.state.keys
            obj.jage=obj.jage+'￥'
          var list=this.state.data.map((item)=>{
            if(item.key==this.state.keys){
              item=obj
            }
            return item
           })
          this.setState({
            data:list
          })
          {this.success1()}
          }

          this.handleOk()
          this.props.form.setFields({"name":""})

        }
      });
    };
  //页面初始化
    componentDidMount(){
      this.setState({
        total:this.state.data.length
      })
    }
    
    showModal(type,val) {
      if(type=='xiu'){
        this.setState({
          keys:val.key,
          type:'xiu'
        })
        this.props.form.setFieldsValue({"name":val.name})
      }
      this.setState({
        visible: true,
      });
      
    };
    handleOk = () => {
      
        this.setState({
          visible: false,
          confirmLoading: false,
        });
    };
    handleCancel = () => {
      this.props.form.setFields({"name":""})
      this.setState({
        visible: false,
      });
      
    };
    //删除
    deletes(id){
      var list=this.state.data.filter((item)=>{
          return item.key!=id
      })
      this.setState({
        data:list,
        total:list.length
      })
      this.setState({})
      {this.success3()}
    }
      render(){
        const { getFieldDecorator } = this.props.form;
        const { visible, confirmLoading, ModalText ,type} = this.state;
          return(
              <div style={{ background: '#ECECEC' }}>
              <Card title="分类管理" bordered={false} style={{ width: '100%' }} extra={<Button onClick={()=>{this.showModal()}} type="primary" icon="plus">添加分类</Button>} >
                <Table bordered={true} columns={this.state.columns} dataSource={this.state.data} 
                     pagination={{
                      pageSize: 5,
                      total:this.state.total,}}
                />
                <div>
                <Modal
                  title="添加商品"
                  visible={visible}
                  onOk={(event)=>{this.handleSubmit(type,event)}}
                  okText={'确认'}
                  cancelText={'取消'}
                  confirmLoading={confirmLoading}
                  onCancel={this.handleCancel}
                >
                  
                <Form onSubmit={this.handleSubmit}  className="login-form">
                  <Form.Item label="名称">
                    {getFieldDecorator('name', {
                      rules: [
                        {
                          required: true,
                          message: '商品名称不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                </Form>
                </Modal>
                </div>
              </Card>
            </div>
          )
      }
  }

  export default  Form.create()(Store);