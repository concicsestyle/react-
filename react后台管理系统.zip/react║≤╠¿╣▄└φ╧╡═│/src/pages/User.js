import React, { Component } from 'react';
import { Card ,message,Button,Radio,Select, Table, Divider,Pagination, Tag ,Modal,Form, Input,Icon} from 'antd';

const { Option } = Select;

 class User extends Component{
    constructor(){
        super()
        this.timestampToTime=this.timestampToTime
        this.state={
            visible: false,
            confirmLoading: false,
            total:10,
            time:'',
            keys:0,
            type:'add',
            columns : [
              {
                title: '用户名',
                dataIndex: 'name',
                key: 'name',
              },
              {
                title: '邮箱',
                dataIndex: 'email',
                key: 'email',
              },
              {
                title: '电话',
                dataIndex: 'phone',
                key: 'phone',
              },
              {
                title: '注册时间',
                key: 'time',
                dataIndex: 'time',
                render: text => <span>{this.timestampToTime(text)}</span>,
                
              },
              {
                title: '权限角色',
                key: 'order',
                dataIndex: 'order'
              },
              {
                title: '操作',
                key: 'action',
                render: (text, record) => (
                  <span>
                  <Button onClick={()=>{this.showModal('xiu',record)}}>修改</Button>
                  <Divider type="vertical" />
                  <Button onClick={()=>{this.deletes(record.key)}}>删除</Button>
                </span>
                ),
              },
            ],
            data :[
              {
                key: '1',
                name: 'John Brown',
                email: '12345678@qq.com',
                phone: '1324468904',
                time: 1582132047642,
                order:'管理员',
              },
              {
                key: '2',
                name: 'Jim Green',
                email: '98745678@qq.com',
                phone: '13245678903',
                time: 1582138447642,
                order:'普通用户',

              },
              {
                key: '3',
                name: 'Joe Black',
                email: '43245678@qq.com',
                phone: '13245674321',
                time: 1582135047642,
                order:'管理员',

              },
              {
                key: '4',
                name: 'Jim Green',
                email: '85215678@qq.com',
                phone: '13245670791',
                time: 1582135047642,
                order:'会员',

              },
              {
                key: '5',
                name: 'Joe Bles',
                email: '61065678@qq.com',
                phone: '13245679512',
                time: 1582135047642,
                order:'管理员',

              },
            ]
          }
      }
      //转化时间格式
      timestampToTime(timestamp) {
        let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        let w = '上午';
        if(date.getHours()>=12){
            w='下午'
        }else{
            w='上午'
        }
        
        return Y+M+D+w+h+m+s;
      }
      //初始化页面数
      componentDidMount(){
        this.setState({
          total:this.state.data.length
        })
      }
      //提交
      handleSubmit (type,e){
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
          if (!err) {
            if(type=='add'){
              var key=new Date()-1
              var val=values
              val.time=new Date()-1
              val.key=key
              var list=this.state.data
              list.push(values)
            this.setState({
              data:list,
              total:list.length
            })
            this.setState({})
            {this.success2()}
            }else{
              this.setState({
                type:'add'
              })
              var obj=values
              obj.key=this.state.keys
              obj.time=this.state.time

            var list=this.state.data.map((item)=>{
              if(item.key==this.state.keys){
                item=obj
              }
              return item
             })
            this.setState({
              data:list
            })
            {this.success1()}
            }
  
            this.handleOk()
            this.props.form.setFields({"name":""})
            this.props.form.setFields({"email":""})
            this.props.form.setFields({"phone":""})
            this.props.form.setFields({"order":""})
  
          }
        });
      };
      //修改按钮
      showModal(type,val){
        if(type=='xiu'){
          this.setState({
            keys:val.key,
            type:'xiu',
            time:val.time,
          })
          this.props.form.setFieldsValue({"name":val.name})
          this.props.form.setFieldsValue({"email":val.email})
          this.props.form.setFieldsValue({"phone":val.phone})
          this.props.form.setFieldsValue({"order":val.order})
        }
        this.setState({
          visible: true,
        });
        
      };
      //确认
      handleOk = () => {
      
        this.setState({
          visible: false,
          confirmLoading: false,
        });
    };
    //取消
    handleCancel = () => {
            this.props.form.setFields({"name":""})
            this.props.form.setFields({"email":""})
            this.props.form.setFields({"phone":""})
            this.props.form.setFields({"order":""})
            this.setState({
        visible: false,
      });
    };
    //删除
    deletes(id){
      var list=this.state.data.filter((item)=>{
          return item.key!=id
      })
      this.setState({
        data:list,
        total:list.length
      })
      this.setState({})
      {this.success3()}
    }
//提示框
success1 = () => {
  message.success('修改成功');
};
success2 = () => {
  message.success('添加成功');
};
success3 = () => {
  message.success('删除成功');
};
    render(){
      const { getFieldDecorator } = this.props.form;
      const { visible, confirmLoading, ModalText,type } = this.state;

        return(
            <div style={{ background: '#ECECEC' }}>
            <Card title="用户管理" bordered={false} style={{ width: '100%' }} extra={<Button onClick={()=>{this.showModal()}} type="primary" icon="plus">添加用户 </Button>} >
              <Table
                  bordered={true}  columns={this.state.columns} dataSource={this.state.data}
                  pagination={{
                    pageSize: 5,
                    total:this.state.total,}}
               />
              <div>
              <Modal
                  title="添加商品"
                  visible={visible}
                  onOk={(event)=>{this.handleSubmit(type,event)}}
                  okText={'确认'}
                  cancelText={'取消'}
                  confirmLoading={confirmLoading}
                  onCancel={this.handleCancel}
                >
                  
                <Form onSubmit={this.handleSubmit}  className="login-form">
                  <Form.Item label="用户名">
                    {getFieldDecorator('name', {
                      rules: [
                        {
                          required: true,
                          message: '用户名不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  
                  <Form.Item label="邮箱">
                    {getFieldDecorator('email', {
                      rules: [
                        {
                          required: true,
                          message: '邮箱不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  <Form.Item label="电话">
                    {getFieldDecorator('phone', {
                      rules: [
                        {
                          required: true,
                          message: '电话不能为空!',
                        },
                      ],
                    })(<Input />)}
                  </Form.Item>
                  <Form.Item label="角色">
                    {getFieldDecorator('order', {
                      rules: [
                        {
                          required: true,
                          message: '请选择用户权限角色!',
                        },
                      ],
                    })
                  (<Select
                  style={{width : 180}}
                    placeholder="选择用户权限角色"   
                    onChange={this.handleSelectChange}
                  >
                    <Option value="管理员">管理员</Option>
                    <Option value="会员">会员</Option>
                    <Option value="普通用户">普通用户</Option>

                  </Select>)}
                  </Form.Item>
                </Form>
                </Modal>
              </div>
            </Card>
          </div>
        )
    }
}

export default  Form.create()(User);