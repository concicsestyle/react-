import  axios from 'axios'

//创建axios对象

const service =axios.create({
    baseURL:'',//请求根路径
    timeout:10000//请求超时时间
})

//添加一个请求拦截器,每次发请求的时候都会执行的函数，比如：为请求添加一个请求头信息sessionId
axios.interceptors.request.use(function(config){
    config.headers['Token']= "haha ,这是测试！！"//获取token
    return config;
},function(error){
    return Promise.reject(error)
});
//添加一个响应拦截器,当后台返回特定的状态码的时候，前端做出响应
axios.interceptors.response.use(function(response){
    return response;
},function(error){
    return Promise.reject(error);
});

export default service
