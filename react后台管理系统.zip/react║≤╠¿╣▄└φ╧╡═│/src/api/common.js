import fetch from '../util/fetch'

export function getLogin(data){
    return fetch({
        method:'POST',
        url:"/api/index.php",
        data:data
    })
};
// export function getLogin(obj){
//     return fetch()({
//         method:'GET',
//         url:"/api/Login",
//         params:obj
//     })
// }