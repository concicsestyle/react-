import React,{lazy,Suspense} from 'react';

import logo from './logo.svg';
import 'antd/dist/antd.css';
import './App.css';
import {BrowserRouter as Router,Switch,Route,NavLink,Redirect} from "react-router-dom";

import Errors from './pages/Errors'

import Dashbord from './pages/Dashbord'

import Login from './pages/Login'


// let Dashbord=lazy(()=>import('./pages/Dashbord'))//当webpack读到动态的import的时候，就把里面的文件从主bundle里面抽离
// let Login=lazy(()=>import('./pages/Login'))

function App() {
  return (
    <Router>
    <div className="App">
    <Suspense fallback={<div>Loading...</div>}>
      <Switch>{/* 默认匹配一个 */}
        <Route path="/login" component={Login}></Route>
        <Route path="/index" component={Dashbord}></Route>
        <Redirect from="/" to="/login"></Redirect>{/* 重定向,404的是路由到哪里 */}
        <Route component={Errors}></Route>
      </Switch>
    </Suspense>
    </div>
    </Router>
  );
}

export default App;
